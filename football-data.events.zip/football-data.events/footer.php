    <div class="footer" style="background: #0275d8 none repeat scroll 0 0; border: medium none; border-radius: 0; min-height: 50px; position: relative;">
		<div class="sub-footer" style="color: #fff; font-size: 15px;padding-top: 15px; vertical-align: middle; text-align:center;">@Copyright 2017. All rights reserved.</div>
	<script src="assets/js/jquery-1.12.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
