# phplib-football-data
Small library that implements some functionalities of football-data.org's API.

See the code in index.php on how to use the library, which should (only) serve you as a starting point. I didn't take much care of variable visibility, maybe I also missed to meet some up-to-date PHP coding standards. I just coded it down so it is readable, workable and understandable ;)

Setup a webserver and call the index.php in a browser. Afterwards check the code to see how these results are achieved.

Best,
daniel
